import { useState, useEffect } from 'react';
import { getQuestions, submitAssessment } from '../services/api';

const ANSWER_OPTIONS = [
  { value: 'yes', label: 'Ano', className: 'selected-yes' },
  { value: 'partial', label: 'Částečně', className: 'selected-partial' },
  { value: 'no', label: 'Ne', className: 'selected-no' },
  { value: 'na', label: 'N/A', className: 'selected-na' },
];

function Assessment({ companyInfo, onComplete, onBack }) {
  const [domains, setDomains] = useState([]);
  const [currentDomain, setCurrentDomain] = useState(0);
  const [answers, setAnswers] = useState({});
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    getQuestions()
      .then(data => { setDomains(data); setLoading(false); })
      .catch(() => { setError('Nepodařilo se načíst otázky. Je backend spuštěn?'); setLoading(false); });
  }, []);

  const setAnswer = (qid, val) => setAnswers(prev => ({ ...prev, [qid]: val }));

  const domain = domains[currentDomain];
  const totalQ = domains.reduce((s, d) => s + d.questions.length, 0);
  const answeredQ = Object.keys(answers).length;
  const progress = totalQ > 0 ? (answeredQ / totalQ) * 100 : 0;
  const isLast = currentDomain === domains.length - 1;

  const handleNext = () => {
    if (isLast) { handleSubmit(); return; }
    setCurrentDomain(p => p + 1);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePrev = () => {
    if (currentDomain > 0) { setCurrentDomain(p => p - 1); window.scrollTo({ top: 0, behavior: 'smooth' }); }
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const result = await submitAssessment({
        ...companyInfo,
        answers: Object.entries(answers).map(([question_id, value]) => ({ question_id, value })),
      });
      onComplete(result);
    } catch { setError('Odeslání selhalo. Zkuste to znovu.'); setSubmitting(false); }
  };

  if (loading) return <div className="text-center mt-48"><div className="text-mono text-muted" style={{ fontSize: 13 }}>Načítání...</div></div>;
  if (error) return <div className="text-center mt-48"><div style={{ color: 'var(--danger)', marginBottom: 16, fontSize: 14 }}>{error}</div><button className="btn" onClick={onBack}>← Zpět</button></div>;
  if (!domain) return null;

  return (
    <div className="fade-in">
      <div className="progress-meta">
        <span>{answeredQ} z {totalQ} odpovězeno</span>
        <span>{Math.round(progress)}%</span>
      </div>
      <div className="progress-bar">
        <div className="progress-fill" style={{ width: `${progress}%` }} />
      </div>

      <div className="domain-nav">
        {domains.map((d, i) => {
          const done = d.questions.every(q => answers[q.id] !== undefined);
          let cls = 'domain-pill';
          if (i === currentDomain) cls += ' active';
          else if (done) cls += ' complete';
          return <button key={d.id} className={cls} onClick={() => setCurrentDomain(i)}>{i + 1}</button>;
        })}
      </div>

      <div className="mb-24">
        <div className="section-label">{domain.article_ref}</div>
        <h2 className="section-title">{domain.name_cs}</h2>
        <p className="section-desc">{domain.name_en}</p>
      </div>

      {domain.questions.map((q) => (
        <div key={q.id} className="card" style={{ borderColor: answers[q.id] ? 'var(--border-subtle)' : undefined }}>
          <p style={{ fontSize: 14, fontWeight: 500, marginBottom: 3, lineHeight: 1.5 }}>{q.text_cs}</p>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', lineHeight: 1.5 }}>{q.text_en}</p>
          <div className="answer-group">
            {ANSWER_OPTIONS.map(opt => (
              <button key={opt.value} className={`answer-btn ${answers[q.id] === opt.value ? opt.className : ''}`} onClick={() => setAnswer(q.id, opt.value)}>
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      ))}

      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 28 }}>
        <button className="btn" onClick={currentDomain === 0 ? onBack : handlePrev}>
          ← {currentDomain === 0 ? 'Zpět' : 'Předchozí'}
        </button>
        <button className={`btn ${isLast ? 'btn-primary' : ''}`} onClick={handleNext} disabled={submitting}>
          {submitting ? 'Odesílání...' : isLast ? 'Zobrazit výsledky →' : 'Další →'}
        </button>
      </div>
    </div>
  );
}

export default Assessment;
