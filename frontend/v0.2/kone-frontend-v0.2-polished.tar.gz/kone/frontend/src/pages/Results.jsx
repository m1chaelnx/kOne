function Results({ result, onRestart }) {
  if (!result) return null;

  const statusColor = { compliant: 'var(--success)', partial: 'var(--warning)', non_compliant: 'var(--danger)' };
  const statusText = { compliant: 'Vyhovující', partial: 'Částečně vyhovující', non_compliant: 'Nevyhovující' };
  const barColor = (p) => p >= 80 ? 'var(--success)' : p >= 50 ? 'var(--warning)' : 'var(--danger)';

  return (
    <div className="fade-in">
      <div className="text-center mb-8" style={{ marginTop: 16 }}>
        <div className="section-label">Assessment results</div>
        <h1 style={{ fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em' }}>{result.company_name}</h1>
        <p className="text-mono" style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 4 }}>
          {new Date(result.timestamp).toLocaleDateString('cs-CZ')} · {result.sector} · {result.company_size}
        </p>
      </div>

      <div className={`score-circle ${result.overall_status}`}>
        <div className="score-number" style={{ color: statusColor[result.overall_status] }}>
          {Math.round(result.overall_percentage)}%
        </div>
        <div className="score-label">{result.overall_score}/{result.max_score}</div>
      </div>

      <div className="text-center mb-32">
        <span className={`status-badge ${result.overall_status}`}>{statusText[result.overall_status]}</span>
      </div>

      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-number" style={{ color: 'var(--danger)' }}>{result.critical_gaps}</div>
          <div className="stat-label">Kritické mezery</div>
        </div>
        <div className="stat-card">
          <div className="stat-number" style={{ color: 'var(--warning)' }}>{result.total_gaps}</div>
          <div className="stat-label">Celkem mezer</div>
        </div>
        <div className="stat-card">
          <div className="stat-number" style={{ color: 'var(--accent)' }}>
            {result.domain_scores.filter(d => d.status === 'compliant').length}/{result.domain_scores.length}
          </div>
          <div className="stat-label">Domén v souladu</div>
        </div>
      </div>

      <div className="card" style={{ padding: '24px 28px' }}>
        <div className="section-label">Domain breakdown</div>
        <h3 style={{ fontSize: 16, fontWeight: 600, marginBottom: 20 }}>Přehled domén</h3>
        {result.domain_scores.map(ds => (
          <div key={ds.domain_id} className="domain-bar">
            <div className="domain-bar-header">
              <span className="domain-bar-name">{ds.domain_name_cs}</span>
              <span className="domain-bar-pct" style={{ color: barColor(ds.percentage) }}>{Math.round(ds.percentage)}%</span>
            </div>
            <div className="domain-bar-track">
              <div className="domain-bar-fill" style={{ width: `${ds.percentage}%`, background: barColor(ds.percentage) }} />
            </div>
          </div>
        ))}
      </div>

      {result.priority_actions.length > 0 && (
        <div className="mt-32">
          <div className="section-label">Priority actions</div>
          <h3 style={{ fontSize: 16, fontWeight: 600, marginBottom: 4 }}>Prioritní akce</h3>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 16 }}>Nejdůležitější kroky k nápravě</p>
          {result.priority_actions.map((gap, i) => (
            <div key={i} className={`gap-item weight-${gap.weight}`}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                <span className="text-mono" style={{
                  fontSize: 10, padding: '2px 6px', borderRadius: 3,
                  background: gap.weight >= 5 ? 'var(--danger-bg)' : gap.weight >= 4 ? 'var(--warning-bg)' : 'rgba(255,255,255,0.05)',
                  color: gap.weight >= 5 ? 'var(--danger)' : gap.weight >= 4 ? 'var(--warning)' : 'var(--text-muted)',
                }}>{gap.weight}/5</span>
                <span className="gap-question" style={{ marginBottom: 0 }}>{gap.question_cs}</span>
              </div>
              <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 8 }}>{gap.question_en}</div>
              <div className="gap-fix"><strong>→ </strong>{gap.remediation}</div>
              <div className="gap-ref">{gap.article_ref} · {gap.domain_name_cs}</div>
            </div>
          ))}
        </div>
      )}

      {result.domain_scores.filter(ds => ds.gaps.length > 0).length > 0 && (
        <div className="mt-32">
          <div className="section-label">Full gap analysis</div>
          <h3 style={{ fontSize: 16, fontWeight: 600, marginBottom: 16 }}>Všechny zjištěné mezery</h3>
          {result.domain_scores.filter(ds => ds.gaps.length > 0).map(ds => (
            <div key={ds.domain_id} className="mb-24">
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                <span style={{ width: 6, height: 6, borderRadius: '50%', background: barColor(ds.percentage), flexShrink: 0 }} />
                <span style={{ fontSize: 14, fontWeight: 500 }}>{ds.domain_name_cs}</span>
                <span className="text-mono" style={{ fontSize: 11, color: 'var(--text-muted)' }}>{Math.round(ds.percentage)}%</span>
              </div>
              {ds.gaps.map((gap, i) => (
                <div key={i} className={`gap-item weight-${gap.weight}`}>
                  <div className="gap-question">{gap.question_cs}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 6 }}>{gap.question_en}</div>
                  <div className="gap-fix"><strong>→ </strong>{gap.remediation}</div>
                  <div className="gap-ref">{gap.article_ref}</div>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}

      <div className="mt-48 text-center" style={{ paddingBottom: 32 }}>
        <div className="divider" />
        <button className="btn btn-primary" onClick={onRestart} style={{ marginRight: 12 }}>Nové hodnocení</button>
        <button className="btn" onClick={() => window.print()}>Tisk / Print</button>
      </div>
    </div>
  );
}

export default Results;
