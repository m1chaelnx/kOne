import { useState } from 'react';

const SECTORS = [
  { value: 'energy', label: 'Energetika / Energy' },
  { value: 'transport', label: 'Doprava / Transport' },
  { value: 'healthcare', label: 'Zdravotnictví / Healthcare' },
  { value: 'digital_infra', label: 'Digitální infrastruktura / Digital infrastructure' },
  { value: 'ict_services', label: 'ICT služby / ICT services' },
  { value: 'public_admin', label: 'Veřejná správa / Public administration' },
  { value: 'manufacturing', label: 'Výroba / Manufacturing' },
  { value: 'finance', label: 'Finance / Finance' },
  { value: 'water', label: 'Vodní hospodářství / Water' },
  { value: 'food', label: 'Potravinářství / Food' },
  { value: 'postal', label: 'Poštovní služby / Postal' },
  { value: 'waste', label: 'Odpadové hospodářství / Waste management' },
  { value: 'chemicals', label: 'Chemický průmysl / Chemicals' },
  { value: 'research', label: 'Výzkum / Research' },
  { value: 'defense', label: 'Obranný průmysl / Defense industry' },
  { value: 'other', label: 'Jiné / Other' },
];

const SIZES = [
  { value: 'micro', label: '1–9 zaměstnanců' },
  { value: 'small', label: '10–49 zaměstnanců' },
  { value: 'medium', label: '50–249 zaměstnanců' },
  { value: 'large', label: '250+ zaměstnanců' },
];

function Welcome({ onStart }) {
  const [name, setName] = useState('');
  const [size, setSize] = useState('');
  const [sector, setSector] = useState('');
  const canStart = name.trim() && size && sector;

  return (
    <div className="fade-in">
      <div className="text-center" style={{ marginBottom: 40, marginTop: 24 }}>
        <div className="section-label">Compliance assessment</div>
        <h1 style={{ fontSize: 32, fontWeight: 700, letterSpacing: '-0.03em', marginBottom: 12 }}>
          Is your organization NIS2 ready?
        </h1>
        <p style={{ fontSize: 15, color: 'var(--text-secondary)', maxWidth: 480, margin: '0 auto', lineHeight: 1.7 }}>
          Zjistěte stav souladu vaší organizace se zákonem o kybernetické bezpečnosti za 10 minut.
        </p>
      </div>

      <div className="card" style={{ maxWidth: 460, margin: '0 auto', padding: '28px 28px 32px' }}>
        <div className="mb-16">
          <label>Název organizace / Organization name</label>
          <input type="text" placeholder="např. Moje Firma s.r.o." value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div className="mb-16">
          <label>Velikost / Size</label>
          <select value={size} onChange={(e) => setSize(e.target.value)}>
            <option value="">Vyberte...</option>
            {SIZES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
        </div>
        <div className="mb-24">
          <label>Sektor / Sector</label>
          <select value={sector} onChange={(e) => setSector(e.target.value)}>
            <option value="">Vyberte...</option>
            {SECTORS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
        </div>
        <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => canStart && onStart({ company_name: name.trim(), company_size: size, sector })} disabled={!canStart}>
          Začít hodnocení →
        </button>
      </div>

      <div className="stat-grid" style={{ maxWidth: 460, margin: '32px auto 0' }}>
        <div className="stat-card">
          <div className="stat-number" style={{ color: 'var(--accent)' }}>41</div>
          <div className="stat-label">otázek</div>
        </div>
        <div className="stat-card">
          <div className="stat-number" style={{ color: 'var(--accent)' }}>10</div>
          <div className="stat-label">domén</div>
        </div>
        <div className="stat-card">
          <div className="stat-number" style={{ color: 'var(--accent)' }}>10 min</div>
          <div className="stat-label">čas</div>
        </div>
      </div>
    </div>
  );
}

export default Welcome;
